"use strict";
const $ = (id) => document.getElementById(id);

// ---- chrome.storage.local with an in-memory mirror (so the rest of the code is simple) ----
let store = {};
const sget = (k, d) => (store[k] !== undefined && store[k] !== null) ? store[k] : d;
function sset(k, v) {
  store[k] = v;
  try { if (typeof chrome !== "undefined" && chrome.storage) chrome.storage.local.set({ [k]: v }); } catch (e) {}
}
function sdel(keys) {
  keys.forEach((k) => { delete store[k]; });
  try { if (typeof chrome !== "undefined" && chrome.storage) chrome.storage.local.remove(keys); } catch (e) {}
}

// ---- Gemini key ----
const KEY_K = "mc_dash_gemini_key";
const getKey = () => sget(KEY_K, "");
function askKey() {
  const cur = getKey();
  const k = window.prompt("Paste your Gemini API key (stored on this device only, sent only to Google):", cur);
  if (k !== null) sset(KEY_K, k.trim());
}

// One raw call to a given model. Returns { ok:true, text } or { ok:false, retriable, status, msg }.
// The key travels in a HEADER, never in the URL, so it can't end up in logs or error strings.
async function geminiCall(model, promptText) {
  const url = "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent";
  let res, data;
  try {
    res = await fetch(url, { method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": getKey() },
      body: JSON.stringify({ contents: [{ parts: [{ text: promptText }] }] }) });
  } catch (e) { return { ok: false, retriable: true, status: 0, msg: "Network error (" + e.message + ")" }; }
  try { data = await res.json(); } catch (e) { data = {}; }
  if (!res.ok) {
    const msg = (data && data.error && data.error.message) ? data.error.message : ("HTTP " + res.status);
    // 429 (rate limit / "high demand") and 5xx (overloaded) are transient → worth retrying.
    const retriable = res.status === 429 || res.status >= 500;
    return { ok: false, retriable, status: res.status, msg };
  }
  const out = data && data.candidates && data.candidates[0] && data.candidates[0].content
    && data.candidates[0].content.parts && data.candidates[0].content.parts[0]
    ? data.candidates[0].content.parts[0].text : "";
  return { ok: true, text: (out || "").trim() };
}

// Real AI call. When Gemini is "overloaded / high demand" it retries with backoff and falls back
// across models, so transient load no longer surfaces as an error. Only hard errors (bad key, bad
// request) are returned right away.
async function geminiComplete(promptText) {
  if (!getKey()) { askKey(); if (!getKey()) return "Add your Gemini API key with the 🔑 button (bottom-left), then ask again!"; }
  const models = ["gemini-2.5-flash-lite", "gemini-2.5-flash", "gemini-2.0-flash"];
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  let lastStatus = 0, lastMsg = "";
  for (const model of models) {
    for (let attempt = 0; attempt < 3; attempt++) {
      const r = await geminiCall(model, promptText);
      if (r.ok) return r.text || "Hmm, my pickaxe slipped — try asking again?";
      lastStatus = r.status; lastMsg = r.msg;
      if (!r.retriable) return "⚠️ Gemini " + r.status + ": " + r.msg + "  —  fix it with the 🔑 button.";
      await sleep(600 * Math.pow(2, attempt)); // 0.6s → 1.2s → 2.4s
    }
  }
  return "⚠️ Gemini is swamped right now (status " + (lastStatus || "503") + "). I retried and switched models — give it a few seconds and try again.";
}

// Everything opens in THIS tab — it's a new-tab page, navigating away from it is the point.
function go(url) { window.location.assign(url); }

function init() {
  // One-time cleanup of retired storage: the old pinned daily task, the old persisted chat
  // transcript (chat is per-tab now), and v1.1 leftovers.
  sdel(["mc_dash_daily", "mc_dash_chat"]);

  // ---- Clock ----
  function tick() {
    const d = new Date(); let h = d.getHours(); const ap = h >= 12 ? "PM" : "AM"; h = h % 12 || 12;
    const p = (n) => String(n).padStart(2, "0");
    $("clock").textContent = p(h) + ":" + p(d.getMinutes()) + ":" + p(d.getSeconds());
    $("ampm").textContent = ap;
    $("date").textContent = d.toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric", year: "numeric" });
  }
  tick(); setInterval(tick, 1000);

  // ---- Theme ----
  const themes = {
    Sky: "linear-gradient(180deg,#5fb8ef 0%,#8fd2f3 30%,#bfe9ff 60%,#d8f3c8 85%,#b6e08a 100%)",
    Sunset: "linear-gradient(180deg,#ff9e6b 0%,#ffb682 28%,#ffd49e 55%,#ffe7c2 80%,#f3b06a 100%)",
    Night: "linear-gradient(180deg,#16224f 0%,#23386f 35%,#37539b 65%,#5874b8 88%,#7f9bd6 100%)"
  };
  function applyTheme(t) {
    $("root").style.background = themes[t] || themes.Sky;
    sset("mc_dash_theme", t);
    document.querySelectorAll(".theme-btn").forEach((b) => {
      const on = b.dataset.theme === t;
      b.style.background = on ? "rgba(255,255,255,.92)" : "rgba(255,255,255,.16)";
      b.style.color = on ? "#2a4a66" : "#fff";
    });
  }
  document.querySelectorAll(".theme-btn").forEach((b) => b.addEventListener("click", () => applyTheme(b.dataset.theme)));
  applyTheme(sget("mc_dash_theme", "Sky"));

  // ---- Search / Wiki (same tab) ----
  function gsearch() { const q = $("searchInput").value.trim(); if (q) go("https://www.google.com/search?q=" + encodeURIComponent(q)); }
  $("searchBtn").addEventListener("click", gsearch);
  $("searchInput").addEventListener("keydown", (e) => { if (e.key === "Enter") gsearch(); });
  function wiki() { const q = $("wikiInput").value.trim(); if (q) go("https://minecraft.wiki/w/Special:Search?search=" + encodeURIComponent(q)); }
  $("wikiBtn").addEventListener("click", wiki);
  $("wikiInput").addEventListener("keydown", (e) => { if (e.key === "Enter") wiki(); });

  // ---- To-Do ----
  let todos = sget("mc_dash_todos", []);
  // Drop the old pinned-daily leftovers so nothing 10SecEveryDay-specific ships to everyone.
  todos = todos.filter((t) => (t.text || "").trim().toLowerCase() !== "upload 10sec vid");
  let todoFull = false;

  function measureTodoCap() {
    // The list box is height-capped in CSS; once it would need to scroll, adding is closed
    // off (finish or remove something first) so tasks can never pile past the panel.
    requestAnimationFrame(() => {
      const el = $("todoList");
      todoFull = el.scrollHeight > el.clientHeight + 2;
      $("todoFull").style.display = todoFull ? "block" : "none";
      $("todoAdd").style.opacity = todoFull ? .45 : 1;
      $("todoAdd").style.cursor = todoFull ? "not-allowed" : "pointer";
      $("todoInput").placeholder = todoFull ? "List full — clear one first" : "Add a task…";
    });
  }

  function renderTodos() {
    const el = $("todoList"); el.innerHTML = "";
    todos.forEach((t, i) => {
      const row = document.createElement("div");
      row.style.cssText = "display:flex;align-items:center;gap:11px;background:rgba(255,255,255,.16);border:2px solid rgba(255,255,255,.25);border-radius:14px;padding:9px 11px;flex:none;";
      const chk = document.createElement("button");
      chk.textContent = t.done ? "✔" : "";
      chk.style.cssText = "flex:none;width:24px;height:24px;cursor:pointer;border-radius:8px;border:none;background:rgba(255,255,255,.95);color:#2e9b2e;font-size:16px;font-weight:800;";
      chk.onclick = () => { todos[i].done = !todos[i].done; sset("mc_dash_todos", todos); renderTodos(); };
      const sp = document.createElement("span");
      sp.textContent = t.text;
      sp.style.cssText = "flex:1;font-size:15px;font-weight:500;text-decoration:" + (t.done ? "line-through" : "none") + ";opacity:" + (t.done ? .6 : 1) + ";";
      const del = document.createElement("button");
      del.textContent = "×";
      del.style.cssText = "flex:none;width:30px;height:30px;cursor:pointer;border:none;border-radius:10px;color:#fff;font-size:15px;font-weight:700;background:linear-gradient(180deg,#ff6a6a,#e23b3b);box-shadow:0 4px 0 #b62a2a;";
      del.onclick = () => { todos.splice(i, 1); sset("mc_dash_todos", todos); renderTodos(); };
      row.append(chk, sp, del); el.appendChild(row);
    });
    measureTodoCap();
  }
  function addTodo() {
    if (todoFull) return;
    const t = $("todoInput").value.trim(); if (!t) return;
    todos.push({ text: t, done: false }); sset("mc_dash_todos", todos); $("todoInput").value = ""; renderTodos();
  }
  $("todoAdd").addEventListener("click", addTodo);
  $("todoInput").addEventListener("keydown", (e) => { if (e.key === "Enter") addTodo(); });
  renderTodos();

  // ---- Quick Links (no defaults; same-tab; Add hides when the box is full) ----
  let links = sget("mc_dash_links", []);
  // One-time migration: strip the exact old preinstalled defaults (YouTube / Claude); links
  // the player added themselves are untouched. New installs simply start empty.
  if (!sget("mc_dash_links_migrated", false)) {
    links = links.filter((q) => !((q.label === "YouTube" && /^https?:\/\/(www\.)?youtube\.com\/?$/i.test(q.url || ""))
      || (q.label === "Claude" && /^https?:\/\/(www\.)?claude\.ai\/?$/i.test(q.url || ""))));
    sset("mc_dash_links", links);
    sset("mc_dash_links_migrated", true);
  }

  function renderLinks() {
    const el = $("linkList"); el.innerHTML = "";
    links.forEach((q, i) => {
      const wrap = document.createElement("div"); wrap.style.cssText = "display:flex;gap:7px;align-items:stretch;flex:none;";
      const open = document.createElement("button");
      open.textContent = q.label; open.className = "pix";
      open.style.cssText = "flex:1;min-width:0;border:none;cursor:pointer;border-radius:15px;padding:13px;font-size:11px;color:#fff;background:linear-gradient(180deg,#6fc24a,#4d9b2c);box-shadow:0 6px 0 #3c7d22,inset 0 2px 0 rgba(255,255,255,.45);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;";
      open.onclick = () => go(q.url);
      const rm = document.createElement("button");
      rm.textContent = "×";
      rm.style.cssText = "flex:none;width:40px;border:none;cursor:pointer;border-radius:13px;color:#fff;font-size:16px;font-weight:700;background:rgba(120,70,10,.32);";
      rm.onclick = () => { links.splice(i, 1); sset("mc_dash_links", links); renderLinks(); };
      wrap.append(open, rm); el.appendChild(wrap);
    });
    const add = document.createElement("button");
    add.textContent = "+ Add Link"; add.className = "pix";
    add.style.cssText = "flex:none;border:2px dashed rgba(255,255,255,.7);cursor:pointer;border-radius:15px;padding:12px;font-size:10px;color:#4a3408;background:rgba(255,255,255,.18);";
    add.onclick = () => {
      const label = window.prompt("Link name (e.g. Discord):"); if (!label) return;
      let url = window.prompt("Link URL (e.g. discord.com):"); if (!url) return;
      if (!/^https?:\/\//i.test(url)) url = "https://" + url;
      links.push({ label: label.trim(), url: url.trim() }); sset("mc_dash_links", links); renderLinks();
    };
    el.appendChild(add);
    // Once the box would scroll, hide Add — the cap is literally "how many fit".
    requestAnimationFrame(() => {
      if (el.scrollHeight > el.clientHeight + 2) {
        add.textContent = "Full — remove a link to add";
        add.style.cursor = "not-allowed";
        add.onclick = null;
        add.style.opacity = .55;
      }
    });
  }
  renderLinks();

  // ---- Steve Bot chat (Gemini) ----
  // The transcript lives ONLY in this tab — closing the tab forgets the chat, every new tab
  // starts fresh. Memory ON = follow-ups are answered WITH this tab's conversation as
  // context (resending it costs more quota). Memory OFF = every question is one-shot.
  const CHAT_GREETING = { role: "bot", content: "Hiya! I'm Steve Bot ⛏️ Ask me anything about Minecraft — redstone, builds, mob farms, enchants — and I'll help you out!" };
  let chatMem = sget("mc_dash_chat_mem", true);
  let chat = [CHAT_GREETING];
  let chatLoading = false;
  function renderMemUi() {
    $("chatMem").textContent = "Memory: " + (chatMem ? "ON" : "OFF");
    $("chatMemHint").textContent = chatMem
      ? "🧠 Memory ON — Steve remembers THIS tab's chat for follow-ups (resends it, so it uses quota faster). Closing the tab forgets everything."
      : "Memory OFF — every question is answered on its own. Closing the tab forgets everything.";
  }
  function renderChat() {
    const box = $("chatBox"); box.innerHTML = "";
    chat.forEach((m) => {
      const b = document.createElement("div");
      if (m.role === "user") {
        b.style.cssText = "flex:none;align-self:flex-end;max-width:84%;background:#fff;color:#23303a;padding:9px 13px;border-radius:16px 16px 5px 16px;font-size:14.5px;font-weight:500;line-height:1.45;box-shadow:0 3px 8px rgba(0,0,0,.14);white-space:pre-wrap;overflow-wrap:break-word;";
      } else {
        b.style.cssText = "flex:none;align-self:flex-start;max-width:84%;background:rgba(255,255,255,.18);border:1.5px solid rgba(255,255,255,.28);color:#fff;padding:9px 13px;border-radius:16px 16px 16px 5px;font-size:14.5px;font-weight:500;line-height:1.45;white-space:pre-wrap;overflow-wrap:break-word;";
      }
      b.textContent = m.content; box.appendChild(b);
    });
    if (chatLoading) {
      const t = document.createElement("div");
      t.style.cssText = "flex:none;align-self:flex-start;background:rgba(255,255,255,.18);border:1.5px solid rgba(255,255,255,.28);padding:11px 15px;border-radius:16px 16px 16px 5px;display:flex;gap:5px;";
      t.innerHTML = '<span style="width:7px;height:7px;border-radius:50%;background:#fff;animation:typing 1s infinite;"></span><span style="width:7px;height:7px;border-radius:50%;background:#fff;animation:typing 1s infinite .2s;"></span><span style="width:7px;height:7px;border-radius:50%;background:#fff;animation:typing 1s infinite .4s;"></span>';
      box.appendChild(t);
    }
    box.scrollTop = box.scrollHeight;
  }
  async function sendChat() {
    const q = $("chatInput").value.trim(); if (!q || chatLoading) return;
    chat.push({ role: "user", content: q }); $("chatInput").value = ""; chatLoading = true; renderChat();
    let prompt = "You are Steve Bot, a cheerful, knowledgeable Minecraft expert assistant on a player's homepage. Keep replies short (1-4 sentences), friendly and practical, with a little blocky-game charm. ";
    if (chatMem) { // send this tab's conversation as context (this is what costs extra quota)
      prompt += "Conversation so far:\n";
      chat.slice(-8).forEach((m) => { prompt += (m.role === "user" ? "Player: " : "Steve Bot: ") + m.content + "\n"; });
    } else { // one-shot: only the current question leaves the device
      prompt += "The player asks:\nPlayer: " + q + "\n";
    }
    prompt += "Steve Bot:";
    const reply = await geminiComplete(prompt);
    chat.push({ role: "bot", content: reply });
    if (chat.length > 60) chat.splice(0, chat.length - 60); // bound this tab's transcript
    chatLoading = false; renderChat();
  }
  $("chatSend").addEventListener("click", sendChat);
  $("chatInput").addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendChat(); } });
  $("chatClear").addEventListener("click", () => { chat = [{ role: "bot", content: "Chat cleared! What do you want to build today? ⛏️" }]; renderChat(); });
  $("chatMem").addEventListener("click", () => {
    chatMem = !chatMem;
    sset("mc_dash_chat_mem", chatMem); // the SETTING persists; the transcript never does
    renderMemUi();
  });
  renderMemUi();
  renderChat();

  // ---- Tools panel: Notes / Waypoints / Timers (everything saved, switch any time) ----
  const toolBody = $("toolBody");
  const btnCss = "border:none;cursor:pointer;border-radius:13px;padding:10px 14px;font-family:'Press Start 2P',monospace;font-size:10px;color:#3a2a08;background:linear-gradient(180deg,#ffe27a,#f4b932);box-shadow:0 4px 0 #c08e1c,inset 0 2px 0 rgba(255,255,255,.5);";
  const rowCss = "display:flex;align-items:center;gap:8px;background:rgba(255,255,255,.16);border:2px solid rgba(255,255,255,.25);border-radius:13px;padding:8px 10px;flex:none;";
  const xCss = "flex:none;width:28px;height:28px;cursor:pointer;border:none;border-radius:9px;color:#fff;font-size:14px;font-weight:700;background:rgba(60,10,10,.35);";

  // --- Notes: create as many as you want; open one, type, ◀ Back to the list. Autosaved. ---
  let notes = sget("mc_dash_notes", []);
  let openNoteId = null;
  const saveNotes = () => sset("mc_dash_notes", notes);
  const noteTitle = (n) => {
    const first = (n.text || "").split("\n").find((l) => l.trim()) || "";
    return first.trim().slice(0, 26) || "Untitled note";
  };

  function renderNotes() {
    toolBody.innerHTML = "";
    const note = notes.find((n) => n.id === openNoteId);
    if (note) { // editor view
      const top = document.createElement("div");
      top.style.cssText = "display:flex;align-items:center;gap:8px;margin-bottom:9px;";
      const back = document.createElement("button");
      back.textContent = "◀ Back"; back.style.cssText = btnCss;
      back.onclick = () => { openNoteId = null; renderTool(); };
      const del = document.createElement("button");
      del.textContent = "Delete"; del.style.cssText = btnCss + "background:linear-gradient(180deg,#ff8a8a,#e23b3b);box-shadow:0 4px 0 #a82626;color:#fff;";
      del.onclick = () => { notes = notes.filter((n) => n.id !== note.id); saveNotes(); openNoteId = null; renderTool(); };
      top.append(back, del);
      const ta = document.createElement("textarea");
      ta.value = note.text || "";
      ta.placeholder = "Write your note… (saves by itself)";
      ta.style.cssText = "width:100%;height:190px;resize:none;border:none;outline:none;border-radius:14px;padding:11px 13px;font-family:'Fredoka',sans-serif;font-size:14.5px;font-weight:500;line-height:1.5;color:#26313a;background:rgba(255,255,255,.95);box-shadow:inset 0 2px 4px rgba(0,0,0,.14);";
      let deb;
      ta.addEventListener("input", () => {
        note.text = ta.value; note.updated = Date.now();
        clearTimeout(deb); deb = setTimeout(saveNotes, 250);
      });
      const hint = document.createElement("div");
      hint.textContent = "Saved on this device automatically.";
      hint.style.cssText = "font-size:12px;font-weight:500;opacity:.85;margin-top:7px;";
      toolBody.append(top, ta, hint);
      ta.focus();
      return;
    }
    // list view
    const add = document.createElement("button");
    add.textContent = "+ New note";
    add.style.cssText = btnCss + "width:100%;margin-bottom:9px;";
    add.onclick = () => {
      const n = { id: Date.now() + "" + Math.floor(Math.random() * 1e4), text: "", updated: Date.now() };
      notes.unshift(n); saveNotes(); openNoteId = n.id; renderTool();
    };
    toolBody.appendChild(add);
    const list = document.createElement("div");
    list.style.cssText = "display:flex;flex-direction:column;gap:8px;max-height:230px;overflow-y:auto;padding-right:3px;";
    if (!notes.length) {
      const empty = document.createElement("div");
      empty.textContent = "No notes yet — jot down seeds, base coords, trade ideas…";
      empty.style.cssText = "font-size:13.5px;font-weight:500;opacity:.85;padding:4px 2px;";
      list.appendChild(empty);
    }
    notes.forEach((n) => {
      const row = document.createElement("div"); row.style.cssText = rowCss + "cursor:pointer;";
      const sp = document.createElement("span");
      sp.textContent = "📄 " + noteTitle(n);
      sp.style.cssText = "flex:1;min-width:0;font-size:14px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;";
      const when = document.createElement("span");
      when.textContent = new Date(n.updated || Date.now()).toLocaleDateString(undefined, { month: "short", day: "numeric" });
      when.style.cssText = "flex:none;font-size:11.5px;font-weight:500;opacity:.8;";
      const del = document.createElement("button");
      del.textContent = "×"; del.style.cssText = xCss;
      del.onclick = (e) => { e.stopPropagation(); notes = notes.filter((x) => x.id !== n.id); saveNotes(); renderTool(); };
      row.onclick = () => { openNoteId = n.id; renderTool(); };
      row.append(sp, when, del); list.appendChild(row);
    });
    toolBody.appendChild(list);
  }

  // --- Waypoints: name + x/y/z + dimension; copy puts "x y z" on the clipboard. ---
  let wps = sget("mc_dash_wps", []);
  const saveWps = () => sset("mc_dash_wps", wps);
  const DIMS = ["Overworld", "Nether", "End"];
  const dimIcon = (d) => d === "Nether" ? "🔥" : d === "End" ? "🌌" : "🌳";
  let wpDim = "Overworld";

  function renderWaypoints() {
    toolBody.innerHTML = "";
    const form = document.createElement("div");
    form.style.cssText = "display:flex;flex-direction:column;gap:7px;margin-bottom:9px;";
    const nameIn = document.createElement("input");
    nameIn.placeholder = "Place name (e.g. Base, End portal)…"; nameIn.className = "fld";
    nameIn.style.cssText += ";flex:none;width:100%;padding:9px 11px;font-size:14px;";
    const row2 = document.createElement("div");
    row2.style.cssText = "display:flex;gap:6px;";
    const mkNum = (ph) => {
      const i = document.createElement("input");
      i.placeholder = ph; i.inputMode = "numeric"; i.className = "fld";
      i.style.cssText += ";flex:1;min-width:0;padding:9px 8px;font-size:14px;text-align:center;";
      return i;
    };
    const xIn = mkNum("X"), yIn = mkNum("Y"), zIn = mkNum("Z");
    const dimBtn = document.createElement("button");
    dimBtn.textContent = dimIcon(wpDim);
    dimBtn.title = wpDim + " (click to change)";
    dimBtn.style.cssText = "flex:none;width:42px;cursor:pointer;border:2px solid rgba(255,255,255,.35);border-radius:12px;font-size:16px;background:rgba(255,255,255,.16);";
    dimBtn.onclick = () => { wpDim = DIMS[(DIMS.indexOf(wpDim) + 1) % DIMS.length]; dimBtn.textContent = dimIcon(wpDim); dimBtn.title = wpDim + " (click to change)"; };
    row2.append(xIn, yIn, zIn, dimBtn);
    const save = document.createElement("button");
    save.textContent = "+ Save waypoint"; save.style.cssText = btnCss + "width:100%;";
    save.onclick = () => {
      const nm = nameIn.value.trim() || "Waypoint";
      const num = (el) => { const v = parseInt(el.value.trim(), 10); return isNaN(v) ? 0 : v; };
      wps.unshift({ name: nm.slice(0, 40), dim: wpDim, x: num(xIn), y: num(yIn), z: num(zIn) });
      saveWps(); renderTool();
    };
    form.append(nameIn, row2, save);
    toolBody.appendChild(form);
    const list = document.createElement("div");
    list.style.cssText = "display:flex;flex-direction:column;gap:8px;max-height:190px;overflow-y:auto;padding-right:3px;";
    if (!wps.length) {
      const empty = document.createElement("div");
      empty.textContent = "Save coords you never want to lose — base, villages, portals.";
      empty.style.cssText = "font-size:13.5px;font-weight:500;opacity:.85;padding:2px;";
      list.appendChild(empty);
    }
    wps.forEach((w, i) => {
      const row = document.createElement("div"); row.style.cssText = rowCss;
      const sp = document.createElement("span");
      sp.textContent = dimIcon(w.dim) + " " + w.name;
      sp.title = w.dim;
      sp.style.cssText = "flex:1;min-width:0;font-size:13.5px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;";
      const co = document.createElement("span");
      co.textContent = w.x + " " + w.y + " " + w.z;
      co.style.cssText = "flex:none;font-family:'Press Start 2P',monospace;font-size:9px;opacity:.95;";
      const cp = document.createElement("button");
      cp.textContent = "📋"; cp.title = "Copy \"x y z\"";
      cp.style.cssText = "flex:none;width:30px;height:28px;cursor:pointer;border:none;border-radius:9px;font-size:13px;background:rgba(255,255,255,.22);";
      cp.onclick = () => {
        const txt = w.x + " " + w.y + " " + w.z;
        try { navigator.clipboard.writeText(txt); cp.textContent = "✔"; setTimeout(() => { cp.textContent = "📋"; }, 900); }
        catch (e) { window.prompt("Copy the coords:", txt); }
      };
      const del = document.createElement("button");
      del.textContent = "×"; del.style.cssText = xCss;
      del.onclick = () => { wps.splice(i, 1); saveWps(); renderTool(); };
      row.append(sp, co, cp, del); list.appendChild(row);
    });
    toolBody.appendChild(list);
  }

  // --- Timers: a stopwatch and a countdown. Both keep running via timestamps, so they
  //     survive closing the tab (state is saved on every button press). ---
  let sw = sget("mc_dash_stopwatch", { running: false, startMs: 0, accumMs: 0 });
  let cd = sget("mc_dash_countdown", { running: false, endMs: 0, remainMs: 0, durMs: 0 });
  const saveSw = () => sset("mc_dash_stopwatch", sw);
  const saveCd = () => sset("mc_dash_countdown", cd);
  const fmt = (ms) => {
    ms = Math.max(0, ms);
    const t = Math.floor(ms / 100), s = Math.floor(t / 10), m = Math.floor(s / 60);
    return String(m).padStart(2, "0") + ":" + String(s % 60).padStart(2, "0") + "." + (t % 10);
  };
  let swDisp = null, cdDisp = null, cdState = null;

  function renderTimers() {
    toolBody.innerHTML = "";
    const mkCard = (title) => {
      const c = document.createElement("div");
      c.style.cssText = "background:rgba(255,255,255,.14);border:2px solid rgba(255,255,255,.25);border-radius:15px;padding:11px;margin-bottom:9px;";
      const h = document.createElement("div");
      h.textContent = title;
      h.style.cssText = "font-family:'Press Start 2P',monospace;font-size:10px;margin-bottom:8px;text-shadow:1px 1px 0 rgba(0,0,0,.25);";
      c.appendChild(h);
      return c;
    };
    const mkDisp = () => {
      const d = document.createElement("div");
      d.style.cssText = "font-family:'Press Start 2P',monospace;font-size:22px;margin-bottom:9px;text-shadow:2px 2px 0 rgba(0,0,0,.28);";
      d.textContent = "00:00.0";
      return d;
    };
    const smallBtn = (label) => {
      const b = document.createElement("button");
      b.textContent = label;
      b.style.cssText = btnCss + "padding:9px 11px;font-size:9px;";
      return b;
    };

    // Stopwatch
    const c1 = mkCard("⏱ Stopwatch");
    swDisp = mkDisp(); c1.appendChild(swDisp);
    const r1 = document.createElement("div"); r1.style.cssText = "display:flex;gap:7px;";
    const swGo = smallBtn(sw.running ? "Pause" : "Start");
    swGo.onclick = () => {
      if (sw.running) { sw.accumMs += Date.now() - sw.startMs; sw.running = false; }
      else { sw.startMs = Date.now(); sw.running = true; }
      saveSw(); swGo.textContent = sw.running ? "Pause" : "Start";
    };
    const swReset = smallBtn("Reset");
    swReset.onclick = () => { sw = { running: false, startMs: 0, accumMs: 0 }; saveSw(); swGo.textContent = "Start"; };
    r1.append(swGo, swReset); c1.appendChild(r1);

    // Countdown
    const c2 = mkCard("⏳ Countdown");
    cdDisp = mkDisp(); c2.appendChild(cdDisp);
    cdState = document.createElement("div");
    cdState.style.cssText = "font-size:13px;font-weight:700;margin:-3px 0 8px;min-height:16px;";
    c2.appendChild(cdState);
    const presets = document.createElement("div"); presets.style.cssText = "display:flex;gap:6px;margin-bottom:8px;flex-wrap:wrap;";
    [["10s", 10], ["1m", 60], ["5m", 300], ["10m", 600]].forEach(([lab, secs]) => {
      const b = smallBtn(lab);
      b.onclick = () => { cd = { running: true, endMs: Date.now() + secs * 1000, remainMs: 0, durMs: secs * 1000 }; saveCd(); };
      presets.appendChild(b);
    });
    c2.appendChild(presets);
    const r2 = document.createElement("div"); r2.style.cssText = "display:flex;gap:7px;";
    const cdGo = smallBtn("Pause");
    cdGo.onclick = () => {
      if (cd.running) { cd.remainMs = Math.max(0, cd.endMs - Date.now()); cd.running = false; }
      else if (cd.remainMs > 0) { cd.endMs = Date.now() + cd.remainMs; cd.running = true; }
      saveCd();
    };
    const cdReset = smallBtn("Reset");
    cdReset.onclick = () => { cd = { running: false, endMs: 0, remainMs: 0, durMs: 0 }; saveCd(); };
    r2.append(cdGo, cdReset); c2.appendChild(r2);

    toolBody.append(c1, c2);
  }

  // The one ticker keeps whichever timer view is open honest (200ms is smooth enough).
  setInterval(() => {
    if (swDisp && swDisp.isConnected) {
      swDisp.textContent = fmt(sw.accumMs + (sw.running ? Date.now() - sw.startMs : 0));
    }
    if (cdDisp && cdDisp.isConnected) {
      const left = cd.running ? cd.endMs - Date.now() : cd.remainMs;
      if (cd.running && left <= 0) { cd.running = false; cd.remainMs = 0; saveCd(); }
      cdDisp.textContent = fmt(left);
      cdState.textContent = (!cd.running && cd.durMs > 0 && left <= 0) ? "⏰ TIME'S UP!" : "";
    }
  }, 200);

  // --- Tool tab switching (last tab remembered) ---
  let tool = sget("mc_dash_tool", "notes");
  function renderTool() {
    swDisp = cdDisp = cdState = null;
    document.querySelectorAll(".tool-tab").forEach((b) => {
      const on = b.dataset.tool === tool;
      b.style.background = on ? "rgba(255,255,255,.92)" : "rgba(255,255,255,.16)";
    });
    if (tool === "waypoints") renderWaypoints();
    else if (tool === "timers") renderTimers();
    else renderNotes();
  }
  document.querySelectorAll(".tool-tab").forEach((b) => b.addEventListener("click", () => {
    tool = b.dataset.tool; sset("mc_dash_tool", tool); openNoteId = null; renderTool();
  }));
  renderTool();

  // ---- News (live Google News + AI summaries, cached per day; summaries retry gently) ----
  const newsEl = $("newsList");
  const newsToday = () => new Date().toISOString().slice(0, 10);
  const SUMMARY_RETRY_MS = 4 * 3600 * 1000; // failed summaries auto-retry a few hours later

  function renderNews(items, note) {
    newsEl.innerHTML = "";
    (items || []).forEach((n) => {
      const b = document.createElement("button");
      b.style.cssText = "text-align:left;cursor:pointer;border:none;background:transparent;padding:12px 6px;border-bottom:1.5px solid rgba(255,255,255,.16);font-family:'Fredoka',sans-serif;border-radius:8px;width:100%;";
      const head = document.createElement("div");
      const t1 = document.createElement("span"); t1.style.cssText = "color:#ffe9b8;font-weight:600;font-size:16px;"; t1.textContent = n.title;
      const t2 = document.createElement("span"); t2.style.cssText = "color:#e8d3b0;font-weight:500;font-size:15px;"; t2.textContent = n.src ? " — " + n.src : "";
      head.append(t1, t2); b.appendChild(head);
      if (n.summary) { const s = document.createElement("div"); s.style.cssText = "color:#f3e6cf;font-size:13.5px;margin-top:4px;opacity:.92;"; s.textContent = n.summary; b.appendChild(s); }
      b.onclick = () => go(n.link || ("https://www.google.com/search?q=" + encodeURIComponent(n.title)));
      newsEl.appendChild(b);
    });
    if (note) { const d = document.createElement("div"); d.style.cssText = "font-size:12px;color:#f3e6cf;opacity:.85;padding:9px 6px;"; d.textContent = note; newsEl.appendChild(d); }
  }

  async function fetchHeadlines() {
    const res = await fetch("https://news.google.com/rss/search?q=minecraft&hl=en-US&gl=US&ceid=US:en", { cache: "no-store" });
    const xml = await res.text();
    const doc = new DOMParser().parseFromString(xml, "application/xml");
    return [...doc.querySelectorAll("item")].slice(0, 5).map((it) => {
      let title = (it.querySelector("title") ? it.querySelector("title").textContent : "").trim();
      const src = (it.querySelector("source") ? it.querySelector("source").textContent : "").trim();
      if (src && title.endsWith(" - " + src)) title = title.slice(0, -(src.length + 3)).trim();
      const link = (it.querySelector("link") ? it.querySelector("link").textContent : "").trim();
      return { title, src, link };
    });
  }

  async function summarize(items) {
    const prompt = "Summarize each of these Minecraft news headlines in ONE short, plain sentence (max ~14 words). Output exactly one summary per line, in the same order, with no numbering or bullets:\n" + items.map((i) => "- " + i.title).join("\n");
    const out = await geminiComplete(prompt);
    if (!out || out.startsWith("⚠️") || out.startsWith("Add your")) return false;
    const lines = out.split("\n").map((s) => s.replace(/^[\s\-\*\d.\)]+/, "").trim()).filter(Boolean);
    items.forEach((it, i) => { it.summary = lines[i] || ""; });
    return true;
  }

  // Headlines refresh once per day (↻ = right now). AI summaries are added when a key is
  // set; if summarizing fails (quota/overload) the headlines still show and cache, and the
  // AI part retries on ↻ or automatically a few hours later — it can't burn quota on every
  // single new tab like before, which is why summaries used to look like they "never update".
  async function loadNews(force) {
    const cache = sget("mc_dash_news", null);
    const todayCache = cache && cache.date === newsToday() && Array.isArray(cache.items) && cache.items.length;
    if (!force && todayCache) {
      const retryDue = getKey() && !cache.summarized && (Date.now() - (cache.lastTry || 0) > SUMMARY_RETRY_MS);
      if (!retryDue) {
        renderNews(cache.items, cache.summarized ? "" : (getKey()
          ? "AI summaries are resting (quota/overload) — ↻ retries now, or it retries by itself in a few hours."
          : "Add a Gemini key with 🔑 to get AI summaries."));
        return;
      }
    }
    renderNews([], "Loading the latest Minecraft news…");
    let items;
    try { items = await fetchHeadlines(); }
    catch (e) {
      if (todayCache) renderNews(cache.items, "Couldn't refresh — showing today's earlier headlines.");
      else renderNews([], "Couldn't load the news feed.");
      return;
    }
    if (!items.length) { renderNews([], "No news found right now."); return; }
    let summarized = false;
    if (getKey()) summarized = await summarize(items);
    renderNews(items, summarized ? "" : (getKey()
      ? "AI summaries are resting (quota/overload) — ↻ retries now, or it retries by itself in a few hours."
      : "Add a Gemini key with 🔑 to get AI summaries."));
    // ALWAYS cache what we got — headlines shouldn't refetch on every tab just because the
    // AI step failed; only the summary step is retried (see retryDue above).
    sset("mc_dash_news", { date: newsToday(), items, summarized, lastTry: Date.now() });
  }
  $("newsRefresh").addEventListener("click", () => loadNews(true));
  loadNews(false);

  // ---- Key button ----
  $("keyBtn").addEventListener("click", askKey);
}

// Load saved data first, then start the app.
if (typeof chrome !== "undefined" && chrome.storage) {
  chrome.storage.local.get(null, (data) => { store = data || {}; init(); });
} else {
  init();
}
